
mask_kaggle - v2 2022-05-31 4:11am
==============================

This dataset was exported via roboflow.ai on June 28, 2022 at 10:29 AM GMT

It includes 848 images.
Mask are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


